from ques1 import str1

str2 = "I'm a 2nd year B-Tech student. "

print(f"Concatenated String: {str1 + str2}")

# print(" ".join([str1,str2]))