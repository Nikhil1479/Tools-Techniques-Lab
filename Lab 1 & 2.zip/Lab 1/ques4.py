import math

radius = int(input("Enter radius of circle: "))

circumference = 2 * math.pi * radius

area = math.pi **radius
print(f"Circumference: {circumference}")
print(f"Area: {area}")
